//class used to hold variables relating to player bullets

package application;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;

public class Bullet 
{
	//declare variables
	private Image imgLeft, imgRight;
	private ImageView bulletView;
	boolean fired;
	private double xPos, yPos, width, height;
	private int dir;
	final static int RIGHT = 0, LEFT = 1;
	private Rectangle bulletMask;

	//declare construtor
	public Bullet()
	{
		imgRight = new Image("file:Player/bullet_right.gif");
		imgLeft = new Image("file:Player/bullet_left.gif");
		bulletView = new ImageView(imgRight);

		xPos = 0;
		yPos = 0;
		dir = RIGHT;
		fired = false;
		width = bulletView.getImage().getWidth();
		height = bulletView.getImage().getHeight();
		
		bulletMask = new Rectangle(xPos + 125, yPos, 25, 25);
	}

	public Bullet(double x, double y)
	{
		imgRight = new Image("file:bulletRight.png");
		imgLeft = new Image("file:bulletLeft.png");
		bulletView = new ImageView(imgRight);

		xPos = x;
		yPos = y;
		dir = RIGHT;
		fired = false;
		width = bulletView.getImage().getWidth();
		height = bulletView.getImage().getHeight();
	}

	public double getHeight()
	{
		return height;
	}

	public double getWidth()
	{
		return width;
	}

	public int getDirection()
	{
		return dir;
	}

	public ImageView getNode()
	{
		if (dir == RIGHT)
		{
			bulletView.setImage(imgRight);
		}
		else
		{
			bulletView.setImage(imgLeft);
		}
		return bulletView;
	}

	public double getX()
	{
		return xPos;
	}

	public double getY()
	{
		return yPos;
	}

	public boolean isFired()
	{
		return fired;
	}

	public void move()
	{
		if (dir == RIGHT)
		{
			xPos += 25;
		}
		else if (dir == LEFT)
		{
			xPos -= 25;
		}
		bulletView.setX(xPos);
	}

	public void setPosition(double x, double y, int dir)
	{
		this.dir = dir;

		if (this.dir == RIGHT)
		{
			xPos = x - width / 3;
		}
		else
		{
			xPos = x;
		}

		yPos = y + 40;

		fired = true;
		bulletView.setX(xPos);
		bulletView.setY(yPos);
	}

	public void setX(double x)
	{
		xPos = x;
		bulletView.setX(xPos);
	}

	public void setY(double y)
	{
		yPos = y;
		bulletView.setY(yPos);
	}

	public void stopBullet()
	{

	}

	//check if bullet is off the screen
	public boolean isOffScreen(double edge)
	{
		boolean offScreen = false;

		if (xPos + width <= 0 || xPos >= edge)
		{
			offScreen = true;
			fired = false;
		}

		else
		{
			offScreen = false;
		}

		return offScreen;
	}
	
	//update mask drawn over bullet to use for collisions
	public void updateMask()
	{
		bulletMask.setX(xPos + 125); bulletMask.setY(yPos);
	}
}
