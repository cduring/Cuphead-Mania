/* ICS4U1 CPT: Cuphead Mania
 * Chimdi During
 * Conway
 * Program Description
 * - The following code is a video game title "Cuphead Mania". Cuphead Mania is a platformer video game where the user plays as Cuphead while fighting an enemy.
 * - The game involves evading and shooting different types of enemies as the levels progress.
 * - The user will be able to use the arrow keys as well as a few buttons to control the user.
 * Program Details
 * Java FX Components
 * - The program uses FX Components such as Buttons, Labels, and RadioButtons to help the user navigate the game's user display.
 * - The components help the user make decisions such as continuing to play or quitting, or entering uploaded user information.
 * Alerts
 * - The program uses alerts to help the user progress through menus, informing the user on how to progress and what information is being asked for.
 * Layouts
 * - The program uses layouts to format FX Components used throughout the game.
 * Arrays
 * - The program uses arrays to help store multiple of the same object/datatypes used throughout the game.
 * - The program uses 1D arrays to cycle through images of a gif.
 * - The program uses 2D arrays to hold a list of rectangular borders used in the game.
 * - The program uses ArrayLists to create objects for bullets and projectiles.
 * Sorting and Searching Methods
 * - Program uses sorting and searching methods to sort through data held in file objects.
 * Object Oriented Programming
 * - Program uses seperate classes to access groups of related methods and variables related to specific objects.
 * - Program uses to player class, enemy classes, and projectile classes to control movements and images.
 * Inheritance
 * - Program uses inheritance to have subclasses inherit methods of a superclass.
 * Animation
 * - Program uses animation and collision to animate players movements on the stage, and check for collisions between players with enemies and projectiles.
 * Files
 * - Program uses files to store user data and preference.
 * Sounds
 * - Program uses sounds to add background music and sound effects to game elements.
 */


package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;
import java.util.Random;

import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

public class Main extends Application {
	//@Override
	//Declaring global varibales
	private Pane root, mugRoot;
	private Pane healthBar;
	private Rectangle health;
	private GridPane root2;
	private Scene scene;
	private Player player;
	private AnimationTimer animation;
	private KeyFrame kfGravity, kfJump, kfGif, kfLabel, kfLoad, kfDelay, kfMug, flowerKf, kfStage, kfVul, kfMarch;
	private Timeline gravityTimer, jumpTimer, gifTimer, labelTimer, loadTimer, delayTimer, mugTimer, flowerTimer, stageTimer, vulTimer, marchTimer;
	private boolean playLeft, playRight, moveDown, moveLeft, moveRight, cross, labelOn, difSel, nameFound, playing, flowerTime, vulnerable;
	private boolean dupFound;
	private ImageView backview, titleView, gifView, graphic, blackScreen, loadingGif, smokeGif, resultView, fire;
	private Image backgroundPic, titlePic, blackPic, loadingPic, smokePic, deathPic;
	private double vertSpeed, speedInc, prevHealth;
	private Rectangle floor, loadFill, left, right, top, bottom;
	private Rectangle[][] pForms;
	private ArrayList<Bullet> shoot;
	private ArrayList<Projectile> acorns, marchers;
	private Projectile superMarcher;
	private int stage, bulletCount, gifCount, difficulty, substage, zerostage, flowerStage, seconds;
	private int acornCount, temp, healthNum, marcherCount, marchSel, marchAdded, superMarchRun;
	private Image[] gifPics, pformPics;
	private ImageView[] pformViews;
	private Label ttLbl, tutLabel, mugLabel, mugTitle;
	private Font mainFont, alertFont, mainFontTwo, mugFont, mugTitleFont, mugButFont;
	private Alert intro1, submitError, exited;
	private File playerSaves, songFile, floralFile;
	private Media media, floralMedia;
	private MediaPlayer mPlayer, fPlayer;
	private AudioClip gunshot;
	private FileReader fr;
	private BufferedReader readFile;
	private FileWriter fw;
	private BufferedWriter writeFile;
	private String playerName;
	private ArrayList<String> names;
	private Button enter, fight, retry, quit;
	private TextField text;
	private Flower flower;
	private Random rnd;

	public void start(Stage primaryStage) 
	{
		try 
		{
			//initialize global variables
			stage = 0;
			gifCount = 0;
			substage = 0;
			zerostage = 0;

			//initialize fonts
			mainFont = Font.loadFont("file:Fonts/AlegreyaSansSC-Bold.ttf", 80);
			alertFont = Font.loadFont("file:Fonts/AlegreyaSansSC-Regular.ttf", 18);
			mainFontTwo = Font.loadFont("file:Fonts/AlegreyaSansSC-Bold.ttf", 50);
			mugFont = Font.loadFont("file:Fonts/AlegreyaSansSC-Regular.ttf", 28);
			mugButFont = Font.loadFont("file:Fonts/AlegreyaSansSC-Bold.ttf", 30);
			mugTitleFont = Font.loadFont("file:Fonts/AlegreyaSansSC-Bold.ttf", 48);

			//initialize global image objects
			titlePic = new Image("file:titlebackground.png", 1400, 800, false, false);
			titleView = new ImageView(titlePic);
			deathPic = new Image("file:death.png");
			resultView = new ImageView(deathPic);
			gifPics = new Image[36];
			for (int i = 0; i < 36; i++)
			{
				if (i < 9)
					gifPics[i] = new Image("file:Gif Images/cuphead_title_screen_000" + (i + 1) + ".png");
				else
					gifPics[i] = new Image("file:Gif Images/cuphead_title_screen_00" + (i + 1) + ".png");
			}
			gifView = new ImageView(gifPics[0]);
			backgroundPic = new Image("file:background.jpg", 1400, 800, false, false);
			backview = new ImageView(backgroundPic);

			//initialize root and scene
			root = new Pane();
			scene = new Scene(root, titlePic.getWidth(), titlePic.getHeight());

			//initialize label
			ttLbl = new Label();
			ttLbl.setFont(mainFont);
			ttLbl.setTextFill(Color.GOLD);
			ttLbl.setAlignment(Pos.CENTER);
			ttLbl.setTextAlignment(TextAlignment.CENTER);
			ttLbl.setText("press enter to play");
			ttLbl.setMinWidth(700);
			ttLbl.setLayoutX(scene.getWidth() / 2 - 350);
			ttLbl.setLayoutY(600);

			//addding intro items to pane
			root.getChildren().addAll(titleView, gifView, ttLbl);
			gifView.setX(scene.getWidth() / 2 - gifPics[gifCount].getWidth() / 2);
			gifView.setY(scene.getHeight() - gifPics[gifCount].getHeight());

			//initialize global boolean values
			moveDown = true;
			moveLeft = true;
			moveRight = true;
			vertSpeed = 0;
			speedInc = 0.1;
			cross = true;
			labelOn = true;
			difSel = false;
			dupFound = false;
			nameFound = false;
			playing = true;
			seconds = 0;
			flowerTime = false;
			vulnerable = false;
			health = new Rectangle(100, 25, 180, 75);

			//initialize player bull arraylist
			shoot = new ArrayList<Bullet>();
			bulletCount = -1;

			//arraylist to hold user data
			names = new ArrayList<String>();

			//loading screen images
			loadingPic = new Image("file:Player/run_right.gif");
			loadingGif = new ImageView(loadingPic);
			blackPic = new Image("file:blackscreen.png", 1400, 800, false, false);
			blackScreen = new ImageView(blackPic);
			smokePic = new Image("file:smoke.gif", 1600, 1000, false, false);
			smokeGif = new ImageView(smokePic);

			//information error alert
			submitError = new Alert(AlertType.ERROR);
			submitError.setHeaderText(null);
			submitError.setTitle("ERROR");
			submitError.getButtonTypes().clear();
			submitError.getButtonTypes().addAll(ButtonType.OK);

			//label for tutorials
			tutLabel = new Label();
			tutLabel.setAlignment(Pos.CENTER);
			tutLabel.setTextAlignment(TextAlignment.CENTER);
			tutLabel.setFont(mainFontTwo);
			tutLabel.setMinWidth(1400);
			tutLabel.setLayoutX(scene.getWidth() / 2 - 700);
			tutLabel.setLayoutY(100);
			tutLabel.setText("use the arrow keys to move left and right");
			tutLabel.setTextFill(Color.GOLD);

			//label for enemy mugshot screen
			mugLabel = new Label();
			mugLabel.setAlignment(Pos.CENTER);
			mugLabel.setTextAlignment(TextAlignment.CENTER);
			mugLabel.setFont(mugFont);

			mugTitle = new Label();
			mugTitle.setAlignment(Pos.CENTER);
			mugTitle.setTextAlignment(TextAlignment.CENTER);
			mugTitle.setFont(mugTitleFont);

			//initialize enemy object values
			flower = new Flower();
			acornCount = -1;
			marcherCount = -1;
			marchSel = 0;
			marchAdded = 0;

			rnd = new Random();

			//media file and audio clip objects
			songFile = new File("introTune.mp3");
			media = new Media(songFile.toURI().toString());
			mPlayer = new MediaPlayer(media);
			mPlayer.setAutoPlay(true);
			mPlayer.play();

			floralFile = new File("flowerMusic.mp3");
			floralMedia = new Media(floralFile.toURI().toString());
			fPlayer = new MediaPlayer(floralMedia);
			//fPlayer.setAutoPlay(true);

			gunshot = new AudioClip("file:gunshot.MP3");

			//initialize enemy projectile
			superMarcher = new Projectile();
			superMarchRun = 0;
			superMarcher.setImage(2);
			superMarcher.setXDir(superMarcher.LEFT);
			superMarcher.setX(-300);
			superMarcher.setY(-300);
			fire = new ImageView(new Image("file:fire.png", 1400, 800, false, false));

			graphic = new ImageView(new Image("file:alert_pic.png", 40, 40, false, false));

			scene.setOnKeyPressed(new EventHandler<KeyEvent>()
			{
				public void handle (KeyEvent e)
				{
					if (e.getCode() == KeyCode.ENTER)
					{
						if (stage == 0)
						{
							//obtain user experience from alert
							int choice = introSequence();
							//if new player
							if (choice == 0)
							{
								//obtain player info
								playerInfoPane();
								scene.setRoot(root2);
								root2.setCenterShape(true);
								primaryStage.setWidth(220);
								primaryStage.setHeight(350);
								primaryStage.centerOnScreen();
							}
							//if returning player
							else if (choice == 1)
							{
								//search for player info
								playerName = nameLog();
								nameSearch();
								if (nameFound)
								{
									//verify user info
									if (dupFound)
									{
										verifyInfo();
										verifyInfoPane();
										scene.setRoot(root2);
										root2.setCenterShape(true);
										primaryStage.setWidth(220);
										primaryStage.setHeight(350);
										primaryStage.centerOnScreen();
									}
									else
									{
										verifyInfo();
										verifyInfoPane();
										scene.setRoot(root2);
										root2.setCenterShape(true);
										primaryStage.setWidth(220);
										primaryStage.setHeight(350);
										primaryStage.centerOnScreen();
									}
								}
								else
								{
									//obtain user info
									Alert alert = new Alert(AlertType.INFORMATION);
									alert.setHeaderText(null);
									alert.setTitle("Cuphead Mania");
									alert.setGraphic(graphic);
									alert.setContentText("Player not found! Please create a save.");
									alert.showAndWait();
									playerInfoPane();
									scene.setRoot(root2);
									root2.setCenterShape(true);
									primaryStage.setWidth(220);
									primaryStage.setHeight(350);
									primaryStage.centerOnScreen();
								}
							}
							stage++;
						}
						else if (stage == 1)
						{
							//update the main game stage
							mPlayer.stop();
							scene.setRoot(root);
							primaryStage.setWidth(backgroundPic.getWidth());
							primaryStage.setHeight(backgroundPic.getHeight());
							primaryStage.centerOnScreen();
							root.getChildren().removeAll(titleView, gifView);
							if (labelOn)
							{
								root.getChildren().remove(ttLbl);
								labelOn = false;
							}
							//gifTimer.stop();
							primaryStage.setWidth(backgroundPic.getWidth());
							primaryStage.setHeight(backgroundPic.getHeight());
							primaryStage.centerOnScreen();
							player = new Player();
							floor = new Rectangle(0, scene.getHeight() - 30, scene.getWidth(), 25);
							player.setLocation(scene.getWidth() / 2 - player.getWidth() / 2, floor.getY() - player.getHeight() - 20);
							root.getChildren().addAll(backview);
							creatingPlatforms();
							root.getChildren().addAll(player.getNode());
							labelTimer.stop();
							loading();
							delayTimer.play();
							//root.getChildren().addAll(player.getPlayerBase(), player.getPlayerHead(), player.getPlayerLeft(), player.getPlayerRight());
							gravityTimer.play();
							jumpTimer.play();
							stage++;
						}
					}
					if (stage == 2)
					{
						//move player left if within bounds and not intersecting walls
						if (e.getCode() == KeyCode.LEFT)
						{
							player.isMovingLeft = true;
							playLeft = true;
							//update tutorial stage
							if (substage == 0 && zerostage == 0)
							{
								zerostage++;
								tutLabel.setText("use the space button to jump onto platforms");
								tutLabel.setAlignment(Pos.CENTER);
								labelOn = false;
								root.getChildren().remove(tutLabel);
							}
						}
						//move player right if within bounds and not intersecting walls
						if (e.getCode() == KeyCode.RIGHT)
						{
							player.isMovingRight = true;
							playRight = true;
							//update tutorial stage
							if (substage == 0 && zerostage == 0)
							{
								zerostage++;
								tutLabel.setText("use the space button to jump onto platforms");
								tutLabel.setAlignment(Pos.CENTER);
								labelOn = false;
								root.getChildren().remove(tutLabel);
							}
						}
						//move player up for a jump and update gravity variables
						if (e.getCode() == KeyCode.SPACE)
						{
							if (moveDown == false)
							{
								moveDown = true;
								cross = false;
								player.setY(player.getY() - 25);
								vertSpeed = -7;
								speedInc = 0.1;
								jumpTimer.play();
							}
							//update tutorial stage
							if (substage == 0 && zerostage == 1)
							{
								zerostage++;
								tutLabel.setText("use the d key to use cuphead's peashooter");
								tutLabel.setAlignment(Pos.CENTER);
								labelOn = false;
								root.getChildren().remove(tutLabel);
							}
						}
						//create player bullets
						if (e.getCode() == KeyCode.D)
						{
							player.isShooting = true;
							gunshot.play();
							bulletCount++;
							shoot.add(bulletCount, new Bullet());
							shoot.get(bulletCount).setPosition(player.getX(), player.getY(), player.getDirection());
							root.getChildren().add(shoot.get(bulletCount).getNode());
							//update tutorial stage
							if (substage == 0 && zerostage == 2)
							{
								zerostage++;
								tutLabel.setText("you're now ready for some action,\npress enter to rumble");
								tutLabel.setAlignment(Pos.CENTER);
								labelOn = false;
								root.getChildren().remove(tutLabel);
							}
						}
						if (e.getCode() == KeyCode.ENTER)
						{
							//update tutorial
							if (substage == 0 && zerostage == 3)
							{
								substage++;
								labelOn = false;
								root.getChildren().remove(tutLabel);
								labelTimer.stop();
								mugshotLoad();
							}
						}
					}
				}
			});

			scene.setOnKeyReleased(new EventHandler<KeyEvent>()
			{
				public void handle (KeyEvent e)
				{
					if (stage == 2)
					{
						//update player movement variables on key release
						if (e.getCode() == KeyCode.LEFT)
						{
							player.isMovingLeft = false;
							playLeft = false;
						}
						if (e.getCode() == KeyCode.RIGHT)
						{
							player.isMovingRight = false;
							playRight = false;
						}
						if (e.getCode() == KeyCode.D)
						{
							player.isShooting = false;
						}
					}
				}
			});

			animation = new AnimationTimer() 
			{
				public void handle(long val)
				{
					if (stage == 0)
					{

					}
					else if (stage == 2)
					{
						//move players based on movement variables
						moveLeft = true;
						for (int i = 0; i < 4; i++)
						{
							if (player.getPlayerLeft().getBoundsInParent().intersects(pForms[3][i].getBoundsInParent()))
							{
								moveLeft = false;
							}
						}

						moveRight = true;
						for (int i = 0; i < 4; i++)
						{
							if (player.getPlayerRight().getBoundsInParent().intersects(pForms[2][i].getBoundsInParent()))
							{
								moveRight = false;
							}
						}

						if (playLeft && player.getX() > 0 && moveLeft)
						{
							player.moveleft();
						}
						if (playRight && player.getX() + player.getNode().getImage().getWidth() < root.getWidth() && moveRight)
						{
							player.moveright();
						}

						player.getNode();
						player.updateMask();

						//check for player collsions with platforms and floor
						for (int i = 0; i < 4; i++)
						{
							if (!player.getPlayerBaseBounds().intersects(floor.getBoundsInParent()) && !player.getPlayerBaseBounds().intersects(pForms[0][i].getBoundsInParent()) && cross)
							{
								speedInc = 0.1;
							}
						}

						for (int i = 0; i < 4; i++)
						{
							if (player.getPlayerBaseBounds().intersects(pForms[0][i].getBoundsInParent()) && cross)
							{
								speedInc = -0.01;
							}
						}
						//check if bullets leave screen
						for (int i = 0; i <= bulletCount; i++)
						{
							if (shoot.get(i).fired)
							{
								shoot.get(i).move();

								if (shoot.get(i).isOffScreen(root.getWidth()))
								{
									root.getChildren().remove(shoot.get(i).getNode());
									shoot.remove(shoot.get(i));
									bulletCount--;
								}
							}
						}

						//move supermarcher enemy
						if (superMarcher.moving && !superMarcher.isOffScreen(scene.getWidth(), scene.getHeight()))
						{
							superMarcher.bounce(scene.getHeight());
							if (superMarcher.getNode().getBoundsInParent().intersects(player.getNode().getBoundsInParent()))
							{
								root.getChildren().remove(superMarcher);
								death();
							}
							if (player.getPlayerBaseBounds().intersects(floor.getBoundsInParent()) && cross)
							{
								death();
							}
						}

						//move acorn projectiles and check for collisions
						if (acornCount > -1)
						{
							for (int i = 0; i <= acornCount; i++)
							{
								if (acorns.get(i).moving)
								{
									acorns.get(i).translate(16, 8);
								}

								if (acorns.get(i).getNode().getBoundsInParent().intersects(player.getNode().getBoundsInParent()))
								{
									root.getChildren().removeAll(acorns.get(i).getNode(), acorns.get(i).getScreen());
									acorns.remove(acorns.get(i));
									acornCount--;
									death();
								}

								if (acorns.get(i).isOffScreen(root.getWidth(), root.getHeight()))
								{
									root.getChildren().removeAll(acorns.get(i).getNode(), acorns.get(i).getScreen());
									acorns.remove(acorns.get(i));
									acornCount--;
								}

								for (int j = 0; j <= bulletCount; j++)
								{
									if (acornCount > -1)
									{
										if (acorns.get(i).getNode().getBoundsInParent().intersects(shoot.get(j).getNode().getBoundsInParent()))
										{
											root.getChildren().removeAll(acorns.get(i).getNode(), acorns.get(i).getScreen());
											acorns.remove(acorns.get(i));
											acornCount--;

											root.getChildren().remove(shoot.get(j).getNode());
											shoot.remove(shoot.get(j));
											bulletCount--;
										}
									}
								}
							}
						}

						//move marcher objects and check for collisions
						if (marcherCount > -1)
						{
							for (int i = 0; i <= marcherCount; i++)
							{
								marchers.get(i).moveHorizontal();
								if (marchers.get(i).getNode().getBoundsInParent().intersects(player.getNode().getBoundsInParent()))
								{
									root.getChildren().removeAll(marchers.get(i).getNode());
									marchers.remove(marchers.get(i));
									marcherCount--;
									death();
								}

								if (marchers.get(i).isOffScreen(root.getWidth(), root.getHeight()))
								{
									root.getChildren().removeAll(marchers.get(i).getNode(), marchers.get(i).getScreen());
									marchers.remove(marchers.get(i));
									marcherCount--;
								}

								for (int j = 0; j <= bulletCount; j++)
								{
									if (marcherCount > -1)
									{
										if (marchers.get(i).getNode().getBoundsInParent().intersects(shoot.get(j).getNode().getBoundsInParent()))
										{
											root.getChildren().removeAll(marchers.get(i).getNode(), marchers.get(i).getScreen());
											marchers.remove(marchers.get(i));
											marcherCount--;

											root.getChildren().remove(shoot.get(j).getNode());
											shoot.remove(shoot.get(j));
											bulletCount--;
										}
									}
								}
							}
						}

						//update enemy image if in vulnerable state
						if (vulnerable)
						{
							for (int j = 0; j <= bulletCount; j++)
							{
								if (flower.enemyBounds().intersects(shoot.get(j).getNode().getBoundsInParent()))
								{
									health.setWidth(health.getWidth() - 5);
									healthNum -= 5;
									if (healthNum == 0)
									{
										animation.stop();
										gameDone();
									}
									if (healthNum <= prevHealth - 60)
									{
										if (!vulnerable)
										{
											flower.isVulnerable(vulnerable);
											vulTimer.stop();
										}
										else
										{
											vulTimer.stop();
										}
										prevHealth = healthNum;
										playing = true;
										vulnerable = false;
									}	
									root.getChildren().remove(shoot.get(j).getNode());
									shoot.remove(shoot.get(j));
									bulletCount--;
								}
							}
						}

						//prevent player from falling through screen
						if (player.getY() + player.getHeight() >= scene.getHeight())
						{
							player.setY(floor.getY() - player.getHeight());
						}
					}
				}
			};
			animation.start();

			kfGravity = new KeyFrame(Duration.millis(8), new EventHandler<ActionEvent>() 
			{
				public void handle(ActionEvent e) 
				{		
					//move player down by increasing increment(gravity)
					vertSpeed += speedInc;
					player.setY(player.getY() + vertSpeed);

					//check for collisions with floor and platforms
					if (player.getPlayerBaseBounds().intersects(floor.getBoundsInParent()) && cross)
					{
						vertSpeed = 0;
						speedInc = 0;
						moveDown = false;
					}

					for (int i = 0; i < 4; i++)
					{
						if (player.getPlayerBaseBounds().intersects(pForms[0][i].getBoundsInParent()) && cross)
						{
							vertSpeed = 0;
							speedInc = 0;
							moveDown = false;
						}
					}

					for (int i = 0; i < 4; i++)
					{
						if (player.getPlayerHead().intersects(pForms[1][i].getBoundsInParent()))
						{
							player.setY(pForms[1][i].getY() + 1);
							vertSpeed = 0;
						}
					}
					//move marchers down
					if (marcherCount > -1)
					{
						if (marchSel <= marcherCount)
						{
							marchers.get(marchSel).jump();
							if (marchers.get(marchSel).isOffScreen(root.getWidth(), root.getHeight()))
							{
								marchSel = rnd.nextInt(marcherCount + 1);
							}
						}
					}
				}
			});

			//timer to set jump boolean
			kfJump = new KeyFrame(Duration.millis(300), new EventHandler<ActionEvent>() 
			{
				public void handle(ActionEvent e) 
				{		
					cross = true;
					jumpTimer.stop();
				}
			});

			gravityTimer = new Timeline(kfGravity);
			gravityTimer.setCycleCount(Timeline.INDEFINITE);

			jumpTimer = new Timeline(kfJump);
			jumpTimer.setCycleCount(Timeline.INDEFINITE);

			//timer to cycle through title screen gif
			kfGif = new KeyFrame(Duration.millis(40), new EventHandler<ActionEvent>() 
			{
				public void handle(ActionEvent e) 
				{		
					gifCount++;
					if (gifCount == 36)
						gifCount = 0;

					gifView.setImage(gifPics[gifCount]);
					gifView.setX(scene.getWidth() / 2 - gifPics[gifCount].getWidth() / 2);
					gifView.setY(scene.getHeight() - gifPics[gifCount].getHeight());

					flower.cycle();
				}
			});

			gifTimer = new Timeline(kfGif);
			gifTimer.setCycleCount(Timeline.INDEFINITE);
			gifTimer.play();

			//timer to turn on and off labels
			kfLabel = new KeyFrame(Duration.millis(1200), new EventHandler<ActionEvent>() 
			{
				public void handle(ActionEvent e) 
				{		
					if (stage == 0)
					{
						if (labelOn)
						{
							labelOn = false;
							root.getChildren().remove(ttLbl);
						}
						else
						{
							labelOn = true;
							root.getChildren().add(ttLbl);
						}
					}
					else if (stage == 2)
					{
						if (labelOn)
						{
							labelOn = false;
							root.getChildren().remove(tutLabel);
						}
						else
						{
							labelOn = true;
							root.getChildren().add(tutLabel);
						}
					}
				}
			});

			labelTimer = new Timeline(kfLabel);
			labelTimer.setCycleCount(Timeline.INDEFINITE);
			labelTimer.play();

			//timer to fill load rectangle
			kfLoad = new KeyFrame(Duration.millis(50), new EventHandler<ActionEvent>() 
			{
				public void handle(ActionEvent e) 
				{		
					loadFill.setWidth(loadFill.getWidth() + 7.5);

					if (loadFill.getBoundsInParent().intersects(right.getBoundsInParent()))
					{
						loadTimer.stop();
						root.getChildren().removeAll(blackScreen, left, right, top, bottom, loadFill, loadingGif);
					}
				}
			});

			loadTimer = new Timeline(kfLoad);
			loadTimer.setCycleCount(Timeline.INDEFINITE);

			//1.5 second delay
			kfDelay = new KeyFrame(Duration.millis(1500), new EventHandler<ActionEvent>() 
			{
				public void handle(ActionEvent e) 
				{		
					if (flowerTime)
					{
						delayTimer.stop();
						fightTime();
					}
					else
					{
						labelTimer.play();
						delayTimer.stop();
					}
				}
			});

			delayTimer = new Timeline(kfDelay);
			delayTimer.setCycleCount(Timeline.INDEFINITE);

			//timer to load up mugshot
			kfMug = new KeyFrame(Duration.millis(600), new EventHandler<ActionEvent>() 
			{
				public void handle(ActionEvent e) 
				{		
					root.getChildren().remove(smokeGif);
				}
			});

			mugTimer = new Timeline(kfMug);
			mugTimer.setCycleCount(Timeline.INDEFINITE);

			//declare and initialize alert to confirm exits
			exited = new Alert(AlertType.CONFIRMATION);
			exited.setHeaderText(null);
			exited.setTitle("EXIT");
			exited.setGraphic(graphic);
			exited.setContentText("Are you sure you want to exit?");
			exited.getButtonTypes().clear();
			exited.getButtonTypes().addAll(ButtonType.YES, ButtonType.NO);

			//method to control the close window button
			primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() 
			{
				public void handle(WindowEvent e) 
				{
					Optional<ButtonType> result = exited.showAndWait();//show the exited alert

					//if the user does not wish to exit, consume the close window event
					if (result.get() == ButtonType.NO)
						e.consume();
				}
			});	
			primaryStage.setTitle("Cuphead Mania");
			primaryStage.setScene(scene);
			primaryStage.show();
			loading();
			//skip();
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
		}
	}

	public static void main(String[] args) 
	{
		launch(args);
	}
	//create and place platform borders using 2D array
	public void creatingPlatforms()
	{
		pForms = new Rectangle[4][4];

		//TOPS
		for (int cols = 0; cols < 4; cols++)
		{
			pForms[0][cols] = new Rectangle(-200, -200, 250, 25);
			pForms[0][cols].setFill(Color.RED);
			//root.getChildren().addAll(pForms[0][cols]);
		}

		pForms[0][0].setX(scene.getWidth() / 2 - pForms[0][0].getWidth() / 2);
		pForms[0][0].setY(550);

		pForms[0][1].setX(scene.getWidth() / 4 - pForms[0][1].getWidth() / 2 - 50);
		pForms[0][1].setY(375);

		pForms[0][2].setX(scene.getWidth() / 2 + scene.getWidth() / 4 - pForms[0][2].getWidth() / 2 + 50);
		pForms[0][2].setY(375);

		pForms[0][3].setX(scene.getWidth() / 2 - pForms[0][3].getWidth() / 2);
		pForms[0][3].setY(200);

		//BOTTOMS
		for (int cols = 0; cols < 4; cols++)
		{
			pForms[1][cols] = new Rectangle(-200, -200, 250, 25);
			pForms[1][cols].setFill(Color.DEEPSKYBLUE);
			//root.getChildren().addAll(pForms[1][cols]);
		}

		pForms[1][0].setX(scene.getWidth() / 2 - pForms[1][0].getWidth() / 2);
		pForms[1][0].setY(570);

		pForms[1][1].setX(scene.getWidth() / 4 - pForms[1][1].getWidth() / 2 - 50);
		pForms[1][1].setY(395);

		pForms[1][2].setX(scene.getWidth() / 2 + scene.getWidth() / 4 - pForms[1][2].getWidth() / 2 + 50);
		pForms[1][2].setY(395);

		pForms[1][3].setX(scene.getWidth() / 2 - pForms[1][3].getWidth() / 2);
		pForms[1][3].setY(220);

		//LEFTS
		for (int cols = 0; cols < 4; cols++)
		{
			pForms[2][cols] = new Rectangle(-200, -200, 25, 45);
			pForms[2][cols].setFill(Color.HOTPINK);
			//root.getChildren().addAll(pForms[2][cols]);
			pForms[2][cols].setX(pForms[0][cols].getX() - 25);
			pForms[2][cols].setY(pForms[0][cols].getY());
		}

		//RIGHTS
		for (int cols = 0; cols < 4; cols++)
		{
			pForms[3][cols] = new Rectangle(-200, -200, 25, 45);
			pForms[3][cols].setFill(Color.GREENYELLOW);
			//root.getChildren().addAll(pForms[3][cols]);
			pForms[3][cols].setX(pForms[0][cols].getX() + pForms[0][cols].getWidth());
			pForms[3][cols].setY(pForms[0][cols].getY());
		}

		pformPics = new Image[4];
		pformViews = new ImageView[4];
		for (int i = 0; i < 4; i++)
		{
			pformPics[i] = new Image("file:platform.png", 300, 65, false, false);
			pformViews[i] = new ImageView(pformPics[i]);
			pformViews[i].setX(pForms[0][i].getX() + (pForms[0][i].getWidth() / 2) - (pformPics[i].getWidth() / 2));
			pformViews[i].setY(pForms[2][i].getY() + (pForms[2][i].getHeight() / 2) - (pformPics[i].getHeight() / 2));
			root.getChildren().add(pformViews[i]);
		}
	}

	//intro alert to obtain user experience
	public int introSequence()
	{
		//		playerSave = new File("playersaves.txt");
		//		fr = new FileReader(playerSave);
		//		readFile = new BufferedReader(fr);
		//		fw = new FileWriter(playerSave, true);
		//		writeFile = new BufferedWriter(fw);

		intro1 = new Alert(AlertType.CONFIRMATION);
		intro1.setHeaderText(null);
		intro1.setTitle("Cuphead Mania");
		intro1.setGraphic(graphic);
		intro1.setContentText("Welcome to Cuphead Mania!"
				+ "\nAre you a new player or returning to the game?");
		intro1.getButtonTypes().clear();
		ButtonType np = new ButtonType("New Player");
		ButtonType rp = new ButtonType("Returning Player");
		intro1.getButtonTypes().addAll(np, rp);
		Optional<ButtonType> result = intro1.showAndWait();//show the confirm order alert

		if (result.get() == np)
			return 0;
		else if (result.get() == rp)
			return 1;

		return -1;
	}

	//use dialog to obtain user save name
	public String nameLog()
	{
		TextInputDialog intro2 = new TextInputDialog();
		intro2.setHeaderText(null);
		intro2.setTitle("Cuphead Mania");
		intro2.setGraphic(graphic);
		intro2.setContentText("What is the name of your player save?");
		Optional<String> result = intro2.showAndWait();
		return result.get();
	}

	//run pane to obtain player info
	public void playerInfoPane()
	{
		root2 = new GridPane();
		root2.setGridLinesVisible(false);
		root2.setHgap(10);
		root2.setVgap(10);
		root2.setPadding(new Insets(10, 10, 10, 10));
		root2.setStyle("-fx-background-color: rgb(255, 215, 0);");

		Label title = new Label();
		title.setGraphic(new ImageView(new Image("file:titlelabel.png", 200, 50, false, false)));
		title.setAlignment(Pos.CENTER);
		root2.add(title, 0, 0, 2, 1);
		root2.setHalignment(title, HPos.CENTER);

		Label nameText = new Label();
		nameText.setAlignment(Pos.CENTER);
		nameText.setText("Enter your name:");
		nameText.setMinHeight(20);
		nameText.setFont(alertFont);

		text = new TextField();
		text.setAlignment(Pos.CENTER);
		text.setEditable(true);
		text.setFont(alertFont);

		VBox nameBox = new VBox();
		nameBox.setAlignment(Pos.CENTER);
		nameBox.setSpacing(10);
		nameBox.getChildren().addAll(nameText, text);
		root2.add(nameBox, 0, 1, 2, 1);
		root2.setHalignment(nameBox, HPos.CENTER);

		Label difText = new Label();
		difText.setAlignment(Pos.CENTER);
		difText.setText("Choose difficulty:");
		difText.setFont(alertFont);

		RadioButton rb1 = new RadioButton();
		rb1.setText("SIMPLE");
		rb1.setFont(alertFont);
		rb1.setOnAction(e -> rbClicked(rb1));

		RadioButton rb2 = new RadioButton();
		rb2.setText("CHALLENGE");
		rb2.setFont(alertFont);
		rb2.setOnAction(e -> rbClicked(rb2));

		ToggleGroup tg = new ToggleGroup();
		tg.getToggles().addAll(rb1, rb2);

		VBox difBox = new VBox();
		difBox.setAlignment(Pos.CENTER);
		difBox.setSpacing(20);
		difBox.getChildren().addAll(difText, rb1, rb2);
		root2.add(difBox, 0, 2, 2, 1);
		root2.setHalignment(difBox, HPos.CENTER);

		enter = new Button();
		enter.setAlignment(Pos.CENTER);
		enter.setText("SAVE");
		enter.setOnAction(e -> playerInfoEntered(0));
		enter.setFont(alertFont);
		root2.add(enter, 0, 3, 2, 1);
		root2.setHalignment(enter, HPos.CENTER);
	}

	//run pane to verify player info
	public void verifyInfoPane()
	{
		root2 = new GridPane();
		root2.setGridLinesVisible(false);
		root2.setHgap(10);
		root2.setVgap(10);
		root2.setPadding(new Insets(10, 10, 10, 10));
		root2.setStyle("-fx-background-color: rgb(255, 215, 0);");

		Label title = new Label();
		title.setGraphic(new ImageView(new Image("file:titlelabel.png", 200, 50, false, false)));
		title.setAlignment(Pos.CENTER);
		root2.add(title, 0, 0, 2, 1);
		root2.setHalignment(title, HPos.CENTER);

		Label nameText = new Label();
		nameText.setAlignment(Pos.CENTER);
		nameText.setText("Enter your name:");
		nameText.setMinHeight(20);
		nameText.setFont(alertFont);

		text = new TextField();
		text.setAlignment(Pos.CENTER);
		text.setEditable(true);
		text.setFont(alertFont);
		text.setText(playerName);

		VBox nameBox = new VBox();
		nameBox.setAlignment(Pos.CENTER);
		nameBox.setSpacing(10);
		nameBox.getChildren().addAll(nameText, text);
		root2.add(nameBox, 0, 1, 2, 1);
		root2.setHalignment(nameBox, HPos.CENTER);

		Label difText = new Label();
		difText.setAlignment(Pos.CENTER);
		difText.setText("Choose difficulty:");
		difText.setFont(alertFont);

		RadioButton rb1 = new RadioButton();
		rb1.setText("SIMPLE");
		rb1.setFont(alertFont);
		rb1.setOnAction(e -> rbClicked(rb1));

		RadioButton rb2 = new RadioButton();
		rb2.setText("CHALLENGE");
		rb2.setFont(alertFont);
		rb2.setOnAction(e -> rbClicked(rb2));

		if (difficulty == 0)
			rb1.setSelected(true);
		else if (difficulty == 1)
			rb2.setSelected(true);

		ToggleGroup tg = new ToggleGroup();
		tg.getToggles().addAll(rb1, rb2);

		VBox difBox = new VBox();
		difBox.setAlignment(Pos.CENTER);
		difBox.setSpacing(20);
		difBox.getChildren().addAll(difText, rb1, rb2);
		root2.add(difBox, 0, 2, 2, 1);
		root2.setHalignment(difBox, HPos.CENTER);

		enter = new Button();
		enter.setAlignment(Pos.CENTER);
		enter.setText("SAVE");
		enter.setOnAction(e -> playerInfoEntered(1));
		enter.setFont(alertFont);
		root2.add(enter, 0, 3, 2, 1);
		root2.setHalignment(enter, HPos.CENTER);
	}
	//player info found alert
	public void verifyInfo()
	{
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("Cuphead Mania");
		alert.setGraphic(graphic);
		if (dupFound)
			alert.setContentText("Player found! Please confirm your settings.");
		else
			alert.setContentText("Player duplicate found! Please use a different name.");
		alert.showAndWait();
	}

	//write player info to file
	public void playerInfoEntered(int casenario) 
	{
		if (casenario == 0)
		{
			playerName = text.getText();
			playerSaves = new File("playersaves.txt");
			if (!difSel || playerName.equals("") || playerName.equals(null))
			{
				submitError.setContentText("Error! Please fill out all information.");
				submitError.showAndWait();
			}
			else
			{
				try
				{	
					//initialize file writing objects
					fw = new FileWriter(playerSaves, true);
					writeFile = new BufferedWriter(fw);
					writeFile.newLine();
					if (difficulty == 0)	
						writeFile.write(playerName + ", simple");
					else if (difficulty == 1)
						writeFile.write(playerName + ", challenge");
					writeFile.close();
				}
				catch (IOException e)
				{
					System.out.println("IOException error " + e.getMessage());
				}
				catch (Exception e)
				{
					System.out.println("There was an error in writing to the file.");
				}
				root2.getChildren().clear();
				Label lbl = new Label();
				lbl.setFont(alertFont);
				lbl.setAlignment(Pos.CENTER);
				lbl.setTextAlignment(TextAlignment.CENTER);
				lbl.setText("press enter to continue");
				root2.add(lbl, 0, 1, 1, 1);
				root2.setHalignment(lbl, HPos.CENTER);
				root2.setValignment(lbl, VPos.CENTER);
			}
		}
		else if (casenario == 1)
		{
			difSel = true;
			playerName = text.getText();
			if (playerName.equals(""))
			{
				submitError.setContentText("Error! Please fill out all information.");
				submitError.showAndWait();
			}
			else
			{
				try
				{	
					//initialize file writing objects
					fw = new FileWriter(playerSaves, true);
					writeFile = new BufferedWriter(fw);
					writeFile.newLine();
					if (difficulty == 0)	
						writeFile.write(playerName + ", simple");
					else if (difficulty == 1)
						writeFile.write(playerName + ", challenge");
					writeFile.close();
				}
				catch (IOException e)
				{
					System.out.println("IOException error " + e.getMessage());
				}
				catch (Exception e)
				{
					System.out.println("There was an error in writing to the file.");
				}
				root2.getChildren().clear();
				Label lbl = new Label();
				lbl.setFont(alertFont);
				lbl.setAlignment(Pos.CENTER);
				lbl.setText("press enter to continue");
				root2.add(lbl, 0, 1, 1, 1);
				root2.setHalignment(lbl, HPos.CENTER);
				root2.setValignment(lbl, VPos.CENTER);
			}
		}
	}
	//search for player info in files
	public void nameSearch()
	{
		String current;
		playerSaves = new File("playersaves.txt");
		try
		{
			fr = new FileReader(playerSaves);
			readFile = new BufferedReader(fr);
			while ((current = readFile.readLine()) != null)
			{
				String[] info = current.split(", ");
				names.add(info[0].toLowerCase());
				if (info[0].equals(playerName))
				{
					nameFound = true;
					if (info[1].equals("simple"))
						difficulty = 0;
					else if (info[1].equals("challenge"))
						difficulty = 1;
				}
			}
			//close file reading objects
			fr.close();
			readFile.close();

			Collections.sort(names);
			for (int i = 1; i <= names.size(); i++)
			{
				if (names.get(i).equals(names.get(i - 1)))
				{
					dupFound = true;
				}
			}
		}
		catch (IOException e)
		{
			System.out.println("IOException error " + e.getMessage());
		}
		catch (Exception e)
		{
			System.out.println("There was an error in reading the file.");
		}
	}

	//update player difficulty selections
	public void rbClicked(RadioButton rb) 
	{
		difSel = true;
		if (rb.getText().equals("SIMPLE"))
		{
			difficulty = 0;
		}
		else if (rb.getText().equals("CHALLENGE"))
		{
			difficulty = 1;
		}
	}

	//add loading screen to pane
	public void loading()
	{
		//Rectangle layout = new Rectangle(550, 350, 300, 100);
		loadingGif.setX(700 - loadingPic.getWidth() / 2);
		loadingGif.setY(325 - loadingPic.getHeight());
		left = new Rectangle(550, 350, 20, 100);
		right = new Rectangle(830, 350, 20, 100);
		top = new Rectangle(550, 350, 300, 20);
		bottom = new Rectangle(550, 430, 300, 20);
		left.setFill(Color.WHITE);
		right.setFill(Color.WHITE);
		top.setFill(Color.WHITE);
		bottom.setFill(Color.WHITE);
		loadFill = new Rectangle(570, 350, 1, 100);
		loadFill.setFill(Color.WHITE);
		root.getChildren().addAll(blackScreen, left, right, top, bottom, loadFill, loadingGif);
		loadTimer.play();
	}
	//add enemy mugshot pane to root pane
	public void mugshotLoad()
	{
		mugRoot = new Pane();
		mugRoot.setPrefSize(500 , 600);
		mugRoot.setStyle("-fx-background-color: rgb(216, 187, 119);");
		mugRoot.setLayoutX(scene.getWidth() / 2 - mugRoot.getPrefWidth() / 2);
		mugRoot.setLayoutY(scene.getHeight() / 2 - mugRoot.getPrefHeight() / 2);
		mugRoot.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(10))));

		if (substage == 1)
		{
			mugTitle.setMinWidth(500);
			mugTitle.setMinHeight(150);
			mugTitle.setText("Carney Carnation");
			mugTitle.setLayoutX(0);
			mugTitle.setLayoutY(0);

			mugLabel.setMinWidth(500);
			mugLabel.setMinHeight(150);
			mugLabel.setText("\"Fools who attempt to fight this will,\nleave with allergic rhinitis\"");
			mugLabel.setLayoutX(0);
			mugLabel.setLayoutY(320);

			fight = new Button();
			fight.setAlignment(Pos.CENTER);
			fight.setTextAlignment(TextAlignment.CENTER);
			fight.setText("FIGHT");
			fight.setPrefSize(200, 75);
			fight.setStyle("-fx-background-color: rgb(216, 187, 119);");
			fight.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.DASHED, null, new BorderWidths(2))));
			fight.setOnAction(e -> fightTime());
			fight.setFont(mugButFont);

			flower.setMugshot(250 - (flower.getMugshot().getImage().getWidth() / 2), 125);

			fight.setLayoutX(250 - fight.getPrefWidth() / 2);
			fight.setLayoutY(487.5);

			mugRoot.getChildren().addAll(flower.getMugshot(), mugLabel, mugTitle, fight);
		}

		smokeGif.setX(scene.getWidth() / 2 - smokePic.getWidth() / 2);
		smokeGif.setY(scene.getHeight() - smokePic.getHeight());

		root.getChildren().addAll(mugRoot, smokeGif);
		mugTimer.play();		
	}
	//initiate fight sequence
	public void fightTime()
	{
		seconds = 0;
		fPlayer.play();
		flowerTime = true;
		playing = true;
		marchers = new ArrayList<Projectile>();
		mugRoot.getChildren().clear();
		root.getChildren().removeAll(mugRoot);
		root.getChildren().add(flower.getNode());
		flower.setLocation(900, 1000);
		healthBar();
		//timer to move enemy into screen
		flowerKf = new KeyFrame(Duration.millis(40), new EventHandler<ActionEvent>() 
		{
			public void handle(ActionEvent e) 
			{		
				flower.setY(flower.getY() - 10);
				if (flower.getY() < 380)
				{
					flowerTimer.stop();
				}
			}
		});
		flowerTimer = new Timeline(flowerKf);
		flowerTimer.setCycleCount(Timeline.INDEFINITE);
		flowerTimer.play();
		//timer to move through stages of enemy fight
		kfStage = new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>() 
		{
			public void handle(ActionEvent e) 
			{		
				if (playing)
					seconds++;

				if (seconds == 5)
				{
					createAcorns();
				}

				if (seconds == 6)
				{
					for (int i = 0; i <= acornCount; i++)
					{
						root.getChildren().remove(acorns.get(i).getScreen());
					}
				}

				if (seconds == 8)
				{
					shootAcorns();
				}

				if (seconds == 11)
				{
					createAcorns();
				}

				if (seconds == 12)
				{
					for (int i = 0; i <= acornCount; i++)
					{
						root.getChildren().remove(acorns.get(i).getScreen());
					}
				}

				if (seconds == 14)
				{
					shootAcorns();
				}

				if (seconds == 15)
				{
					vulTimer.play();
					playing = false;
					vulnerable = true;
					seconds++;
				}

				if (seconds == 18)
				{
					playing = false;
					createMarchers();
					seconds++;
				}

				if (seconds == 19)
				{
					if (marcherCount < 0)
					{
						playing = true;
					}
				}

				if (seconds == 21)
				{
					vulTimer.play();
					playing = false;
					vulnerable = true;
					seconds++;
				}

				if (seconds == 23)
				{
					playing = false;
					superMarchTime();
					if (superMarchRun > 3)
					{
						seconds++;
						playing = true;
					}
				}

				if (seconds == 25)
				{
					vulTimer.play();
					playing = false;
					vulnerable = true;
					seconds++;
				}
			}
		});
		stageTimer = new Timeline(kfStage);
		stageTimer.setCycleCount(Timeline.INDEFINITE);
		stageTimer.play();
		//timer to cycle enemy image during vulnerable state
		kfVul = new KeyFrame(Duration.millis(500), new EventHandler<ActionEvent>() 
		{
			public void handle(ActionEvent e) 
			{		
				if (vulnerable)
				{
					flower.isVulnerable(vulnerable);
					vulnerable = false;
				}
				else
				{
					flower.isVulnerable(vulnerable);
					vulnerable = true;
				}
			}
		});
		vulTimer = new Timeline(kfVul);
		vulTimer.setCycleCount(Timeline.INDEFINITE);

		acorns = new ArrayList<Projectile>();
		acornCount = -1;

		marcherCount = -1;
		marchers = new ArrayList<Projectile>();
	}
	//method used for game building
	public void skip()
	{
		mPlayer.stop();
		stage = 2;
		player = new Player();
		floor = new Rectangle(0, scene.getHeight() - 30, scene.getWidth(), 25);
		//player.setLocation(scene.getWidth() / 2 - player.getWidth() / 2, floor.getY() - player.getHeight() - 50);
		player.setLocation(scene.getWidth() / 2 - player.getWidth() / 2, 0);
		root.getChildren().addAll(backview);
		creatingPlatforms();
		root.getChildren().addAll(player.getNode());
		labelTimer.stop();
		delayTimer.play();
		//root.getChildren().addAll(player.getPlayerBase(), player.getPlayerHead(), player.getPlayerLeft(), player.getPlayerRight());
		gravityTimer.play();
		cross = false;
		jumpTimer.play();
	}
	//method to add death screen and buttons when player dies
	public void death()
	{
		System.out.println("You died!");
		fPlayer.stop();
		temp = stage;
		stage = 0;
		resultView.setX(100);
		resultView.setY(scene.getHeight() / 2 - deathPic.getHeight() / 2);
		player.setDir(-1);
		player.isDead = true;
		player.isMovingLeft = false;
		player.isMovingRight = false;
		stageTimer.stop();

		retry = new Button();
		retry.setAlignment(Pos.CENTER);
		retry.setTextAlignment(TextAlignment.CENTER);
		retry.setText("RETRY");
		retry.setPrefSize(300, 100);
		retry.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.DASHED, null, new BorderWidths(2))));
		retry.setOnAction(new EventHandler<ActionEvent>() 
		{
			public void handle(ActionEvent event) 
			{
				loading();
				seconds = 0;
				for (int i = 0; i <= acornCount; i++)
				{
					root.getChildren().removeAll(acorns.get(i).getNode(), acorns.get(i).getScreen());
				}
				for (int i = 0; i <= marcherCount; i++)
				{
					root.getChildren().removeAll(marchers.get(0).getNode());
					marchers.remove(marchers.get(0));
				}
				acornCount = -1;
				marcherCount = -1;
				root.getChildren().removeAll(flower.getNode(), resultView, retry, quit);
				stage = temp;
				player.isDead = false;
				player.setLocation(scene.getWidth() / 2 - player.getWidth() / 2, 0);
				reset();
				delayTimer.play();
			}
		});
		retry.setFont(Font.loadFont("file:Fonts/AlegreyaSansSC-Bold.ttf", 40));
		retry.setLayoutX(200);
		retry.setLayoutY(650);

		quit = new Button();
		quit.setAlignment(Pos.CENTER);
		quit.setTextAlignment(TextAlignment.CENTER);
		quit.setText("QUIT");
		quit.setPrefSize(300, 100);
		quit.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.DASHED, null, new BorderWidths(2))));
		quit.setOnAction(new EventHandler<ActionEvent>() 
		{
			public void handle(ActionEvent event) 
			{
				Optional<ButtonType> result = exited.showAndWait();//show the exited alert

				//if the user does not wish to exit, consume the close window event
				if (result.get() == ButtonType.YES)
					System.exit(0);
			}
		});
		quit.setFont(Font.loadFont("file:Fonts/AlegreyaSansSC-Bold.ttf", 40));
		quit.setLayoutX(900);
		quit.setLayoutY(650);
		root.getChildren().addAll(resultView, retry, quit);
	}

	//methods to create and shoot acorn projectiles
	public void createAcorns()
	{
		playing = false;
		acornCount = -1;
		for (int i = 0; i < 6; i++)
		{
			acornCount++;
			acorns.add(acornCount, new Projectile());
			acorns.get(acornCount).setImage(0);
			if (i == 0)
			{
				acorns.get(acornCount).setPosition(100, 200 - acorns.get(acornCount).getHeight() / 2);
			}	
			else if (i == 1)
			{
				acorns.get(acornCount).setPosition(100, 400 - acorns.get(acornCount).getHeight() / 2);
			}
			else if (i == 2)
			{
				acorns.get(acornCount).setPosition(100, 600 - acorns.get(acornCount).getHeight() / 2);
			}
			else if (i == 3)
			{
				acorns.get(acornCount).setPosition(1300 - acorns.get(acornCount).getWidth(), 200 - acorns.get(acornCount).getHeight() / 2);
			}
			else if (i == 4)
			{
				acorns.get(acornCount).setPosition(1300 - acorns.get(acornCount).getWidth(), 400 - acorns.get(acornCount).getHeight() / 2);
			}
			else if (i == 5)
			{
				acorns.get(acornCount).setPosition(1300 - acorns.get(acornCount).getWidth(), 600 - acorns.get(acornCount).getHeight() / 2);
			}
			root.getChildren().addAll(acorns.get(acornCount).getNode(), acorns.get(acornCount).getScreen());
		}
		playing = true;
	}


	public void shootAcorns()
	{
		if (acornCount < 0)
		{
			playing = true;
		}
		else
		{
			playing = false;
			int sel = rnd.nextInt(acornCount + 1);
			if (!acorns.get(sel).moving)
				acorns.get(sel).homing(player.getX(), player.getY());
			acorns.get(sel).moving = true;
			if (acornCount == 0)
			{
				seconds++;
				playing = true;
			}
		}
	}


	//reset game after enemy death
	public void reset()
	{
		moveDown = true;
		moveLeft = true;
		moveRight = true;
		vertSpeed = 0;
		speedInc = 0.1;
		cross = true;
		vulnerable = false;
		health = new Rectangle(100, 25, 180, 75);
		healthNum = 180;
		marchSel = 0;
		seconds = 0;
		superMarchRun = 0;
		root.getChildren().remove(superMarcher.getNode());
		root.getChildren().remove(fire);
		stageTimer.stop();
	}


	//create health bar pane
	public void healthBar()
	{
		healthBar = new Pane();
		healthBar.setPrefSize(300, 100);
		healthBar.setStyle("-fx-background-color: rgb(27, 223, 245);");
		healthBar.setLayoutX(550);
		healthBar.setLayoutY(25);

		Image enemyPic = new Image("file:Mugshots/carney_mug1.png", 50, 50, false, false);
		ImageView picView = new ImageView(enemyPic);
		picView.setX(25);
		picView.setY(25);

		health = new Rectangle(100, 25, 180, 50);
		health.setFill(Color.RED);
		healthNum = 180;
		prevHealth = 180;

		healthBar.getChildren().addAll(picView, health);
		root.getChildren().add(healthBar);
	}


	//create marcher enemies
	public void createMarchers()
	{
		marcherCount = -1;
		kfMarch = new KeyFrame(Duration.millis(1000), new EventHandler<ActionEvent>() 
		{
			public void handle(ActionEvent e) 
			{		
				marcherCount++;
				marchers.add(marcherCount, new Projectile());
				marchers.get(marcherCount).setImage(1);
				marchers.get(marcherCount).setX(1250);
				marchers.get(marcherCount).setY(700);
				marchers.get(marcherCount).setXDir(marchers.get(marcherCount).LEFT);
				root.getChildren().addAll(marchers.get(marcherCount).getNode());
				marchAdded++;
				if (marchAdded == 15)
				{
					marchTimer.stop();
				}
			}
		});
		marchTimer = new Timeline(kfMarch);
		marchTimer.setCycleCount(Timeline.INDEFINITE);
		marchTimer.play();
	}


	//create supermarcher enemy
	public void superMarchTime()
	{
		if (superMarchRun == 0)
		{
			root.getChildren().add(superMarcher.getNode());
			root.getChildren().add(fire);
			fire.setX(0); fire.setY(0);
		}

		if (superMarcher.isOffScreen(scene.getWidth(), scene.getHeight()))
		{
			if (superMarchRun == 0 || superMarchRun == 2)
			{
				superMarcher.setX(1200);
				superMarcher.setY(50);
				superMarcher.setXDir(superMarcher.LEFT);
				superMarcher.moving = true;
				superMarchRun++;
			}
			else
			{
				superMarcher.setX(100);
				superMarcher.setY(50);
				superMarcher.setXDir(superMarcher.RIGHT);
				superMarcher.moving = true;
				superMarchRun++;
			}
		}
	}


	//update screen when game is done
	private void gameDone()
	{
		root.getChildren().add(new ImageView(new Image("file:victory.png")));
		quit = new Button();
		quit.setAlignment(Pos.CENTER);
		quit.setTextAlignment(TextAlignment.CENTER);
		quit.setText("CONTINUE");
		quit.setPrefSize(300, 100);
		quit.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.DASHED, null, new BorderWidths(2))));
		quit.setOnAction(new EventHandler<ActionEvent>() 
		{
			public void handle(ActionEvent event) 
			{
				root.getChildren().clear();
				loading();			
				root.getChildren().addAll(titleView, gifView);
				File songFile = new File("outroMusic.mp3");
				Media media = new Media(songFile.toURI().toString());
				MediaPlayer mPlayer = new MediaPlayer(media);
				mPlayer.setAutoPlay(true);
				mPlayer.play();
			}
		});
		quit.setFont(Font.loadFont("file:Fonts/AlegreyaSansSC-Bold.ttf", 40));
		quit.setLayoutX(550);
		quit.setLayoutY(650);
	}
}
