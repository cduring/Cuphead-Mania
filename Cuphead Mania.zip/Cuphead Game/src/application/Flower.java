//class to control variables and methods related to the enemy

package application;

import java.util.Random;

import javafx.geometry.Bounds;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;

public class Flower extends Enemy{

	private Random rnd;
	private double xPos, yPos, width, height;
	private Image mug1, mug2, idle, attack, blank;
	private Image idlePics[];
	private ImageView mugshot, enemyView;
	boolean vulnerable;
	private Rectangle box;
	private int index;

	public Flower()
	{
		rnd = new Random();

		xPos = 0;
		yPos = 0;

		index = 0;
		idlePics = new Image[20];
		for (int i = 0; i < 20; i++)
		{
			if (i > 8 && i < 16)
				idlePics[i] = new Image("file:Idle/Idle_0" + (i + 1) + ".png", 225, 350, false, false);
			else
				idlePics[i] = new Image("file:Idle/Idle_0" + (i + 1) + ".png", 250, 350, false, false);
		}

		mug1 = new Image("file:Mugshots/carney_mug1.png", 200, 200, false, false);
		mug2 = new Image("file:Mugshots/carney_mug2.png", 200, 200, false, false);
		mugshot = new ImageView(mug1);	

		idle = new Image("file:Flower/idle.gif");
		idle = new Image("file:flowerman.gif");
		blank = new Image("file:blank.png", 300, 300, false, false);
		enemyView = new ImageView(idlePics[index]);
		width = idlePics[index].getWidth();
		height = idlePics[index].getHeight();

		box = new Rectangle(xPos + width / 2, yPos, width / 2, height);

		vulnerable = false;
	}

	public void cycle()
	{
		if (vulnerable)
		{
			enemyView.setImage(blank);
		}
		else
		{
			index++;
			if (index == 20)
			{
				index = 0;
			}
			enemyView.setImage(idlePics[index]);
		}
	}

	public void setX(double x) 
	{
		xPos = x;
		enemyView.setX(xPos);
		box.setX(xPos + width / 2);
	}

	public void setY(double y) 
	{
		yPos = y;
		enemyView.setY(yPos);
		box.setY(yPos);
	}

	public double getX() 
	{
		return xPos;
	}

	public double getY() 
	{
		return yPos;
	}

	public double getWidth() 
	{
		return width;
	}

	public double getHeight() 
	{
		return height;
	}

	public void setLocation(double x, double y) 
	{
		xPos = x;
		enemyView.setX(xPos);
		yPos = y;
		enemyView.setY(yPos);
		box.setX(xPos + width / 2);
		box.setY(yPos);
	}

	public ImageView getNode() 
	{
		return enemyView;
	}

	//return mugshot image of enemy
	public ImageView getMugshot() 
	{
		int ran = rnd.nextInt(2);
		if (ran == 0)
			mugshot.setImage(mug1);
		else
			mugshot.setImage(mug2);			
		return mugshot;
	}

	public void setMugshot(double x, double y)
	{
		mugshot.setX(x);
		mugshot.setY(y);
	}

	//method to set enemy image on and off while vulnerable
	public void isVulnerable(boolean vul) 
	{
		vulnerable = vul;
		if (vul)
		{
			enemyView.setImage(blank);
		}
		else
		{
			enemyView.setImage(idlePics[index]);
		}
	}

	public Bounds enemyBounds()
	{
		return box.getBoundsInParent();
	}

	public void isDead()
	{

	}



}
