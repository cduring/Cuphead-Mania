//Class holding variables and methods related to projectiles used in the game

package application;

import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.shape.Rectangle;

public class Projectile 
{
	//declare global variables
	private Image acorn, chomper, leaf, smokescreen, marcher, specialMarcher;
	private ImageView projView, bombView;
	private double xPos, yPos, width, height, jumpInc;
	private int dir, xDir, yDir;
	final static int RIGHT = 0, LEFT = 1, UP = 2, DOWN = 3;
	boolean moving;
	private Random rnd;

	//declare constructor
	public Projectile()
	{
		rnd = new Random();		
		acorn = new Image("file:Flower/acorn.gif", 50, 50, false, false);
		chomper = new Image("file:Flower/chomper.gif", 40, 60, false, false);
		leaf = new Image("file:Flower/leaf.gif", 40, 40, false, false);
		smokescreen = new Image("file:smokebomb.gif");
		marcher = new Image("file:Flower/marcher.gif", 70, 70, false, false);
		specialMarcher = new Image("file:Flower/marcher.gif", 150, 150, false, false);
		bombView = new ImageView(smokescreen);
		projView = new ImageView(acorn);

		xPos = 0;
		yPos = 0;
		xDir = RIGHT;
		yDir = DOWN;
		
		bombView.setX(xPos - 75);
		bombView.setY(yPos - 25);

		width = projView.getImage().getWidth();
		height = projView.getImage().getHeight();
		
		//jumpInc = -11;
		jumpInc = - (rnd.nextInt(5) + 9);
		
		moving = false;
	}

	//declare methods
	public double getHeight()
	{
		return height;
	}

	public double getWidth()
	{
		return width;
	}

	public int getDirection()
	{
		return xDir;
	}
	
	public int getYDirection()
	{
		return yDir;
	}

	public ImageView getNode()
	{
		return projView;
	}
	
	public ImageView getScreen()
	{
		return bombView;
	}

	public double getX()
	{
		return xPos;
	}

	public double getY()
	{
		return yPos;
	}
	
	public void setXDir(int xDir)
	{
		this.xDir = xDir;
	}
	
	public void setYDir(int yDir)
	{
		this.yDir = yDir;
	}

	public void moveHorizontal()
	{
		if (xDir == RIGHT)
		{
			xPos += 5;
		}
		else if (xDir == LEFT)
		{
			xPos -= 5;
		}
		projView.setX(xPos);
		updateScreen();
	}
	
	public void moveVertical()
	{
		if (yDir == DOWN)
		{
			yPos += 25;
		}
		else if (yDir == UP)
		{
			yPos -= 25;
		}
		projView.setY(yPos);
		updateScreen();
	}
	
	//move projectile up while slowing beginning to move down, mimicking a jump
	public void jump()
	{
		yPos += jumpInc;
		jumpInc += 0.1;
		projView.setY(yPos);
	}
	
	//bounce projectile off top and bottoms of screen
	public void bounce(double bottom)
	{
		if (xDir == RIGHT)
		{
			xPos += 4;
		}
		else if (xDir == LEFT)
		{
			xPos -= 4;
		}
		if (yDir == DOWN)
		{
			yPos += 14;
			if (yPos + height >= bottom)
				yDir = UP;
		}
		else if (yDir == UP)
		{
			yPos -= 14;
			if (yPos <= 0)
				yDir = DOWN;
		}
		projView.setY(yPos);
		projView.setX(xPos);
		updateScreen();
	}
	
	public void translate()
	{
		if (xDir == RIGHT)
		{
			xPos += 25;
		}
		else if (xDir == LEFT)
		{
			xPos -= 25;
		}
		if (yDir == DOWN)
		{
			yPos += 25;
		}
		else if (yDir == UP)
		{
			yPos -= 25;
		}
		projView.setY(yPos);
		projView.setX(xPos);
		updateScreen();
	}
	
	public void translate(double xSpeed, double ySpeed)
	{
		if (xDir == RIGHT)
		{
			xPos += xSpeed;
		}
		else if (xDir == LEFT)
		{
			xPos -= xSpeed;
		}
		if (yDir == DOWN)
		{
			yPos += ySpeed;
		}
		else if (yDir == UP)
		{
			yPos -= ySpeed;
		}
		projView.setY(yPos);
		projView.setX(xPos);
		updateScreen();
	}
	
	//set projectile direction to aim in the direction of the player
	public void homing(double playerX, double playerY)
	{
		if (xPos <= playerX)
			xDir = RIGHT;
		else
			xDir = LEFT;
		
		if (yPos <= playerY)
			yDir = DOWN;
		else
			yDir = UP;
	}
	
	public void setPosition(double x, double y)
	{
		xPos = x;
		yPos = y;
		projView.setX(xPos);
		projView.setY(yPos);
		updateScreen();
	}

	public void setX(double x)
	{
		xPos = x;
		projView.setX(xPos);
		updateScreen();
	}

	public void setY(double y)
	{
		yPos = y;
		projView.setY(yPos);
		updateScreen();
	}

	//update image based on user selection choice
	public void setImage(int choice)
	{
		if (choice == 0)
			projView.setImage(acorn);
		else if (choice == 1)
			projView.setImage(marcher);
		else if (choice == 2)
			projView.setImage(specialMarcher);
		
		width = projView.getImage().getWidth();
		height = projView.getImage().getHeight();
		updateScreen();
	}

	public boolean isOffScreen(double edge, double bottom)
	{
		boolean offScreen = false;

		if (xPos + width <= 0 || xPos >= edge)
		{
			offScreen = true;
		}
		else if (yPos + height <= 0 || yPos >= bottom)
		{
			offScreen = true;
		}
		else
		{
			offScreen = false;
		}

		return offScreen;
	}
	
	//update bomb screen used to spawn in projectiles
	public void updateScreen()
	{
		bombView.setX(xPos - 75);
		bombView.setY(yPos - 25);
	}
}
