//class to hold variables and methods related to the user player

package application;

import javafx.geometry.Bounds;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class Player {

	//global variables
	public boolean isMovingRight, isMovingLeft, isShooting, isDead;
	private Image imgright, imgleft, runright, runleft, shootright, shootleft, rungunright, rungunleft;
	private Image ghost;
	private ImageView playerView;
	final static int right = 0, left = 1;
	private int dir;
	private double xPos, yPos, width, height;
	private Rectangle playerBase, playerHead, playerLeft, playerRight;

	//constructors
	Player()
	{
		imgright = new Image("file:Player/idle_right.gif", 70, 108.5, false, false);
		imgleft = new Image("file:Player/idle_left.gif", 70, 108.5, false, false);
		runright = new Image("file:Player/run_right.gif", 96, 118, false, false);
		runleft = new Image("file:Player/run_left.gif", 96, 118, false, false);
		shootright = new Image("file:Player/shoot_right.gif", 86, 106, false, false);
		shootleft = new Image("file:Player/shoot_left.gif", 86, 106, false, false);
		rungunright = new Image("file:Player/rungun_right.gif", 105, 129, false, false);
		rungunleft = new Image("file:Player/rungun_left.gif", 105, 129, false, false);
		ghost = new Image("file:ghost.gif");
		playerView = new ImageView(imgright);

		dir = right;
		xPos = 0;
		yPos = 0;

		width = playerView.getImage().getWidth();
		height = playerView.getImage().getHeight();

		isMovingRight = false;
		isMovingLeft = false;
		isShooting = false;

		playerBase = new Rectangle(xPos + 15, yPos + height - 5, width - 30, 7.5);
		playerBase.setFill(Color.RED);
		playerHead = new Rectangle(xPos + 20, yPos + 30, width - 40, 10);
		playerHead.setFill(Color.DEEPSKYBLUE);
		playerLeft = new Rectangle(xPos + 5, yPos + 30, 10, height - 21);
		playerLeft.setFill(Color.GREENYELLOW);
		playerRight = new Rectangle(xPos + width - 15, yPos + 30, 10, height - 21);
		playerRight.setFill(Color.HOTPINK);
	}

	Player(double x, double y)
	{
		imgright = new Image("file:Player/idle_right.gif");
		imgleft = new Image("file:Player/idle_left.png");
		playerView = new ImageView(imgright);
		dir = right;
		xPos = x;
		yPos = y;
		width = playerView.getImage().getWidth();
		height = playerView.getImage().getHeight();
		isMovingRight = false;
		isMovingLeft = false;
	}

	Player(double x, double y, int dir)
	{
		imgright = new Image("file:Player/idle_right.gif");
		imgleft = new Image("file:Player/idle_left.png");
		playerView = new ImageView(imgright);
		this.dir = dir;
		xPos = x;
		yPos = y;
		width = playerView.getImage().getWidth();
		height = playerView.getImage().getHeight();
		isMovingRight = false;
		isMovingLeft = false;
	}

	public double getHeight()
	{
		return height;
	}

	public double getWidth()
	{
		return width;
	}

	public int getDirection()
	{
		return dir;
	}

	//method to check if player is dead, moving, shooting, or idle and setting correct image
	public ImageView getNode()
	{
		if (isDead)
			playerView.setImage(ghost);
		else
		{
			if (dir == right && isMovingRight && isShooting)
			{
				playerView.setImage(rungunright);
			}
			else if (dir == left && isMovingLeft && isShooting)
			{
				playerView.setImage(rungunleft);
			}
			else if (dir == right && isMovingRight)
			{
				playerView.setImage(runright);
			}
			else if (dir == left && isMovingLeft)
			{
				playerView.setImage(runleft);
			}
			else if (dir == right && isShooting)
			{
				playerView.setImage(shootright);
			}
			else if (dir == left && isShooting)
			{
				playerView.setImage(shootleft);
			}
			else if (dir == right)
			{
				playerView.setImage(imgright);
			}
			else
			{
				playerView.setImage(imgleft);
			}
		}

		return playerView;
	}

	public double getX()
	{
		return xPos;
	}

	public double getY()
	{
		return yPos;
	}

	public void moveright()
	{
		xPos += 10;
		dir = right;
		playerView.setX(xPos);
	}

	public void moveleft()
	{
		xPos -= 10;
		dir = left;
		playerView.setX(xPos);
	}

	public void moveUp()
	{
		yPos -= 10;
		playerView.setY(yPos);
	}

	public void moveDown()
	{
		yPos += 10;
		playerView.setY(yPos);
	}

	public void setLocation(double x, double y)
	{
		xPos = x;
		yPos = y;
		playerView.setX(xPos);
		playerView.setY(yPos);
	}

	public void setX(double x)
	{
		xPos = x;
	}

	public void setY(double y)
	{
		yPos = y;
	}

	public void setDir(int dir)
	{
		this.dir = dir;
	}

	public Rectangle getPlayerBase()
	{
		return playerBase;
	}

	public Rectangle getPlayerHead()
	{
		return playerHead;
	}

	public Rectangle getPlayerLeft()
	{
		return playerLeft;
	}

	public Rectangle getPlayerRight()
	{
		return playerRight;
	}

	public Bounds getPlayerBaseBounds()
	{
		return playerBase.getBoundsInParent();
	}

	//update the masks controlling player collisions with platforms and floors
	public void updateMask()
	{
		playerView.setX(xPos); playerView.setY(yPos);

		playerBase.setX(xPos + 15); playerBase.setY(yPos + height - 5);
		playerBase.setWidth(width - 30); playerBase.setHeight(7.5);
		playerHead.setX(xPos + 20); playerHead.setY(yPos + 30);
		playerHead.setWidth(width - 40); playerHead.setHeight(10);
		playerLeft.setX(xPos + 5); playerLeft.setY(yPos + 30);
		playerLeft.setWidth(10); playerLeft.setHeight(height - 27);
		playerRight.setX(xPos + width - 15); playerRight.setY(yPos + 30);
		playerRight.setWidth(10); playerRight.setHeight(height - 27);
	}

}
