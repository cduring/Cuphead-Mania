package application;

import javafx.scene.image.ImageView;

public abstract class Enemy {
	
	public abstract void setX(double x);
	public abstract void setY(double y);
	public abstract double getX();
	public abstract double getY();
	public abstract double getWidth();
	public abstract double getHeight();
	public abstract void setLocation(double x, double y);
	public abstract ImageView getNode();
	public abstract ImageView getMugshot();
	public abstract void setMugshot(double x, double y);
	public abstract void isDead();

}
